﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HtmlAgilityPack;

using tursibNow.HtmlService;

namespace tursibNow.Model
{
    /// <summary>
    /// retrieve the bus network information from html pages
    /// </summary>
    public class BusNetworkHtml : IBusNetwork, IEnumerable<Bus>
    {
        //used to retrieve the html from which to extract the bus info
        IHtmlService _htmlService;
        List<Bus> _buses = new List<Bus>();
        public IEnumerable<Bus> Buses 
        {
            get { return _buses; }
        }

        /// <summary>
        /// builds a list of buses from a html file
        /// </summary>
        /// <param name="url"></param>
        public BusNetworkHtml(IHtmlService htmlService)
        {
            _htmlService = htmlService;
            //get the names and numbers of buses
            HtmlDocument busOverview = _htmlService.BusOverview();

            //get the list of buses in the form
            //<a href="/traseu/1"><strong>Cimitir  - Obi/Viile Sibiului</strong></a>
            //see the BusOverview.htm for an example
            var query =
                from busLink in busOverview.DocumentNode.Descendants("a")
                where ((busLink.Attributes["href"] != null) && (busLink.Attributes["href"].Value.Contains("/traseu/"))) &&
                      ((busLink.ParentNode.Attributes["class"] != null) && (busLink.ParentNode.Attributes["class"].Value == "denumire"))
                //bus number contained in the href tag: href = "/traseu/busNumber"
                let busNo = ExtractBusNumber(busLink.Attributes["href"].Value)          
                let busName = busLink.InnerHtml.Replace("<strong>", "").Replace("</strong>", "")
                select new
                {
                    busNo,
                    busName
                };

            //add a new bus for each element in the query
            foreach (var element in query)
            {
                Bus bus = new Bus();

                //get the number and name of the bus
                bus.Number = element.busNo;
                bus.Name = element.busName;

                //get the bus stations based on the bus number / direct
                List<Station> allDirectStations = new List<Station>();
                IEnumerable<string> stationsDirectList = GetStationNames(element.busNo, Direction.dus);
                foreach (var stationStr in stationsDirectList)
                {
                    Station stationDirect = new Station();
                    stationDirect.Name = stationStr;
                    allDirectStations.Add(stationDirect);
                }
                bus.DirectStations = allDirectStations;

                //get the bus stations based on the bus number / reverse
                List<Station> allReverseStations = new List<Station>();
                IEnumerable<string> stationsReverseList = GetStationNames(element.busNo, Direction.intors);
                foreach (var stationStr in stationsReverseList)
                {
                    Station stationReverse = new Station();
                    stationReverse.Name = stationStr;
                    allReverseStations.Add(stationReverse);
                }
                bus.ReverseStations = allReverseStations;

                _buses.Add(bus);
            }
        }

        /// <summary>
        /// extract bus number from href="/traseu/X", where X is the bus number
        /// </summary>
        /// <param name="href">string containing "/traseu/X"</param>
        /// <returns>X</returns>
        private string ExtractBusNumber(string href)
        {
            if (href.Contains('/'))
            {
                return href.Split('/').Last();
            }
            return string.Empty;
        }

        private IEnumerable<string> GetStationNames(string busNo, Direction direction)
        {
            HtmlDocument doc = new HtmlDocument();
            //get html page containing the bus stations info
            doc = _htmlService.BusStations(busNo);

            var stations =
                from statieLink in doc.DocumentNode.Descendants("a")
                where ((statieLink.Attributes["class"] != null) && (statieLink.Attributes["class"].Value == "statie-link")) &&
                      ((statieLink.Attributes["href"] != null) && (statieLink.Attributes["href"].Value.Contains(direction.ToString())))
                select statieLink.InnerHtml.ToLower();

            return stations;
        }
        
        #region IEnumerable<Bus> implementation
        public IEnumerator<Bus> GetEnumerator()
        {
            foreach (Bus bus in Buses)
            {
                yield return bus;
            }
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
        #endregion
    }
}
